The functions in this directory are used to test specific scenarios of the user experience.
